# resolution-independent-vertical-horizontal-layout-in-unity-ui-4-6
Resolution Independent Vertical/Horizontal Layout in Unity UI 4.6

The main goal of this tutorial is to give you Resolution Independent Vertical/Horizontal Layout in Unity UI 4.6.

You can find complete tutorial on [Resolution Independent Vertical/Horizontal Layout in Unity UI 4.6](http://www.theappguruz.com/blog/resolution-independent-vertical-horizontal-layout-in-unity-ui-4-6).

This Tutorial has been presented by The App Guruz - One of the best [Mobile Game Development Company in India](http://www.theappguruz.com/3d-game-development/).
